const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

const TABLE_NAME = 'PodcastFlowPro';

// Import shared utilities
const { createResponse, handleError, getUserFromToken } = require('/opt/nodejs/utils');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
};

exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ''
    };
  }

  try {
    // Get user info from JWT token
    const user = await getUserFromToken(event);
    if (!user || !user.id) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Unauthorized' })
      };
    }
    
    // Extract role and organizationId from the JWT payload directly
    const authHeader = event.headers.Authorization || event.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const payload = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString());
      user.role = payload.role;
      user.organizationId = payload.organizationId;
      user.sub = payload.sub; // Keep the original sub claim
    }
    
    // If role is not in JWT, fetch from database
    if (!user.role && user.id) {
      try {
        const userRecord = await dynamoDb.get({
          TableName: TABLE_NAME,
          Key: {
            PK: `USER#${user.id}`,
            SK: `USER#${user.id}`
          }
        }).promise();
        
        if (userRecord.Item) {
          user.role = userRecord.Item.role;
          user.organizationId = userRecord.Item.organizationId;
        }
      } catch (error) {
        console.warn('Could not fetch user role from database:', error);
      }
    }
    
    console.log('Authenticated user:', user);

    const method = event.httpMethod;
    const pathParameters = event.pathParameters || {};
    
    // For GET requests to /users/{id}, allow users to fetch their own profile
    if (method === 'GET' && (pathParameters.id || pathParameters.userId)) {
      const requestedUserId = pathParameters.id || pathParameters.userId;
      if (requestedUserId === user.id || requestedUserId === user.sub) {
        // User is fetching their own profile - skip role check
        console.log('User fetching own profile, skipping role check');
      } else {
        // Check if user has admin permissions for their organization
        if (!user.role || !['admin', 'master'].includes(user.role)) {
          return {
            statusCode: 403,
            headers: corsHeaders,
            body: JSON.stringify({ error: 'Insufficient permissions. Admin role required.' })
          };
        }
      }
    } else {
      // For other operations, enforce role check
      if (!user.role || !['admin', 'master'].includes(user.role)) {
        return {
          statusCode: 403,
          headers: corsHeaders,
          body: JSON.stringify({ error: 'Insufficient permissions. Admin role required.' })
        };
      }
    }

    const queryParams = event.queryStringParameters || {};
    const body = event.body ? JSON.parse(event.body) : {};

    let result;

    switch (method) {
      case 'GET':
        if (pathParameters.userId || pathParameters.id) {
          result = await getUser(pathParameters.userId || pathParameters.id, user);
        } else {
          result = await getOrganizationUsers(user, queryParams);
        }
        break;
      
      case 'POST':
        result = await createUser(body, user);
        break;
      
      case 'PUT':
        const userIdForUpdate = pathParameters.userId || pathParameters.id;
        if (userIdForUpdate) {
          if (event.resource.includes('/role')) {
            result = await updateUserRole(userIdForUpdate, body, user);
          } else if (event.resource.includes('/status')) {
            result = await updateUserStatus(userIdForUpdate, body, user);
          } else {
            result = await updateUser(userIdForUpdate, body, user);
          }
        } else {
          throw new Error('User ID required for updates');
        }
        break;
      
      case 'DELETE':
        const userIdForDelete = pathParameters.userId || pathParameters.id;
        if (userIdForDelete) {
          result = await deleteUser(userIdForDelete, user);
        } else {
          throw new Error('User ID required for deletion');
        }
        break;
      
      default:
        throw new Error(`Unsupported method: ${method}`);
    }

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(result)
    };

  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: error.statusCode || 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        error: error.message || 'Internal server error',
        details: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};

// Get all users for the organization
async function getOrganizationUsers(authUser, queryParams) {
  try {
    console.log('Getting organization users for:', authUser.organizationId);
    
    // For master users, they can view global users, otherwise organization users only
    let users = [];
    
    if (authUser.role === 'master') {
      // Master users can see all users
      const result = await dynamoDb.scan({
        TableName: TABLE_NAME,
        FilterExpression: 'begins_with(PK, :pk)',
        ExpressionAttributeValues: {
          ':pk': 'USER#'
        }
      }).promise();
      
      users = result.Items || [];
    } else {
      // Admin users can only see users from their organization
      const result = await dynamoDb.scan({
        TableName: TABLE_NAME,
        FilterExpression: 'begins_with(PK, :pk) AND organizationId = :orgId',
        ExpressionAttributeValues: {
          ':pk': 'USER#',
          ':orgId': authUser.organizationId
        }
      }).promise();
      
      users = result.Items || [];
    }

    // Transform DynamoDB items to user objects
    const transformedUsers = users.map(item => ({
      id: item.PK.replace('USER#', ''),
      email: item.email,
      name: item.name || item.email,
      role: item.role || 'client',
      status: item.status || 'active',
      organizationId: item.organizationId,
      phone: item.phone,
      avatar: item.avatar,
      createdAt: item.createdAt || new Date().toISOString(),
      lastLogin: item.lastLogin
    }));

    // Apply filters
    let filteredUsers = transformedUsers;
    
    if (queryParams.role && queryParams.role !== 'all') {
      filteredUsers = filteredUsers.filter(user => user.role === queryParams.role);
    }
    
    if (queryParams.status && queryParams.status !== 'all') {
      filteredUsers = filteredUsers.filter(user => user.status === queryParams.status);
    }

    return {
      users: filteredUsers,
      total: filteredUsers.length
    };

  } catch (error) {
    console.error('Error getting organization users:', error);
    throw error;
  }
}

// Get a specific user
async function getUser(userId, authUser) {
  try {
    const result = await dynamoDb.get({
      TableName: TABLE_NAME,
      Key: {
        PK: `USER#${userId}`,
        SK: `USER#${userId}`
      }
    }).promise();

    if (!result.Item) {
      throw new Error('User not found');
    }

    const user = result.Item;
    
    // Allow users to access their own profile, or admins to access users in their org
    const isOwnProfile = userId === authUser.id || userId === authUser.sub;
    const isSameOrg = user.organizationId === authUser.organizationId;
    const isMaster = authUser.role === 'master';
    
    if (!isOwnProfile && !isMaster && !isSameOrg) {
      throw new Error('Access denied - user not in your organization');
    }

    return {
      id: user.PK.replace('USER#', ''),
      email: user.email,
      name: user.name || user.email,
      role: user.role || 'client',
      status: user.status || 'active',
      organizationId: user.organizationId,
      phone: user.phone,
      avatar: user.avatar,
      createdAt: user.createdAt || new Date().toISOString(),
      lastLogin: user.lastLogin
    };

  } catch (error) {
    console.error('Error getting user:', error);
    throw error;
  }
}

// Create a new user
async function createUser(userData, authUser) {
  try {
    const userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const now = new Date().toISOString();
    
    // For non-master users, force the organization to be the same as the admin
    const organizationId = authUser.role === 'master' ? 
      (userData.organizationId || authUser.organizationId) : 
      authUser.organizationId;

    const userItem = {
      PK: `USER#${userId}`,
      SK: `USER#${userId}`,
      GSI1PK: `ORG#${organizationId}#USERS`,
      GSI1SK: `USER#${userId}`,
      email: userData.email,
      name: userData.name || userData.email,
      role: userData.role || 'client',
      status: userData.status || 'active',
      organizationId: organizationId,
      phone: userData.phone || '',
      createdAt: now,
      updatedAt: now,
      createdBy: authUser.userId
    };

    await dynamoDb.put({
      TableName: TABLE_NAME,
      Item: userItem,
      ConditionExpression: 'attribute_not_exists(PK)'
    }).promise();

    // TODO: Send invitation email to the user
    console.log(`User invitation would be sent to: ${userData.email}`);

    return {
      id: userId,
      email: userItem.email,
      name: userItem.name,
      role: userItem.role,
      status: userItem.status,
      organizationId: userItem.organizationId,
      phone: userItem.phone,
      createdAt: userItem.createdAt
    };

  } catch (error) {
    console.error('Error creating user:', error);
    if (error.code === 'ConditionalCheckFailedException') {
      throw new Error('User already exists');
    }
    throw error;
  }
}

// Update user information
async function updateUser(userId, userData, authUser) {
  try {
    // First check if user exists and admin has access
    const existingUser = await getUser(userId, authUser);
    
    const now = new Date().toISOString();
    
    const updateExpression = [];
    const expressionAttributeValues = {};
    const expressionAttributeNames = {};

    if (userData.name !== undefined) {
      updateExpression.push('#name = :name');
      expressionAttributeNames['#name'] = 'name';
      expressionAttributeValues[':name'] = userData.name;
    }

    if (userData.email !== undefined) {
      updateExpression.push('email = :email');
      expressionAttributeValues[':email'] = userData.email;
    }

    if (userData.phone !== undefined) {
      updateExpression.push('phone = :phone');
      expressionAttributeValues[':phone'] = userData.phone;
    }

    if (userData.role !== undefined && authUser.role === 'master') {
      updateExpression.push('#role = :role');
      expressionAttributeNames['#role'] = 'role';
      expressionAttributeValues[':role'] = userData.role;
    }

    if (userData.status !== undefined) {
      updateExpression.push('#status = :status');
      expressionAttributeNames['#status'] = 'status';
      expressionAttributeValues[':status'] = userData.status;
    }

    if (updateExpression.length === 0) {
      return existingUser;
    }

    updateExpression.push('updatedAt = :updatedAt');
    expressionAttributeValues[':updatedAt'] = now;

    const params = {
      TableName: TABLE_NAME,
      Key: {
        PK: `USER#${userId}`,
        SK: 'PROFILE#'
      },
      UpdateExpression: `SET ${updateExpression.join(', ')}`,
      ExpressionAttributeValues: expressionAttributeValues,
      ReturnValues: 'ALL_NEW'
    };

    if (Object.keys(expressionAttributeNames).length > 0) {
      params.ExpressionAttributeNames = expressionAttributeNames;
    }

    const result = await dynamoDb.update(params).promise();
    const updatedUser = result.Attributes;

    return {
      id: updatedUser.PK.replace('USER#', ''),
      email: updatedUser.email,
      name: updatedUser.name,
      role: updatedUser.role,
      status: updatedUser.status,
      organizationId: updatedUser.organizationId,
      phone: updatedUser.phone,
      createdAt: updatedUser.createdAt,
      updatedAt: updatedUser.updatedAt
    };

  } catch (error) {
    console.error('Error updating user:', error);
    throw error;
  }
}

// Update user role
async function updateUserRole(userId, roleData, authUser) {
  try {
    // Only masters can change roles, or admins can promote/demote within their org
    if (authUser.role !== 'master' && authUser.role !== 'admin') {
      throw new Error('Insufficient permissions to change user roles');
    }

    const existingUser = await getUser(userId, authUser);
    
    const result = await dynamoDb.update({
      TableName: TABLE_NAME,
      Key: {
        PK: `USER#${userId}`,
        SK: 'PROFILE#'
      },
      UpdateExpression: 'SET #role = :role, updatedAt = :updatedAt',
      ExpressionAttributeNames: {
        '#role': 'role'
      },
      ExpressionAttributeValues: {
        ':role': roleData.role,
        ':updatedAt': new Date().toISOString()
      },
      ReturnValues: 'ALL_NEW'
    }).promise();

    const updatedUser = result.Attributes;
    return {
      id: updatedUser.PK.replace('USER#', ''),
      email: updatedUser.email,
      name: updatedUser.name,
      role: updatedUser.role,
      status: updatedUser.status,
      organizationId: updatedUser.organizationId,
      phone: updatedUser.phone,
      createdAt: updatedUser.createdAt,
      updatedAt: updatedUser.updatedAt
    };

  } catch (error) {
    console.error('Error updating user role:', error);
    throw error;
  }
}

// Update user status
async function updateUserStatus(userId, statusData, authUser) {
  try {
    const existingUser = await getUser(userId, authUser);
    
    const result = await dynamoDb.update({
      TableName: TABLE_NAME,
      Key: {
        PK: `USER#${userId}`,
        SK: 'PROFILE#'
      },
      UpdateExpression: 'SET #status = :status, updatedAt = :updatedAt',
      ExpressionAttributeNames: {
        '#status': 'status'
      },
      ExpressionAttributeValues: {
        ':status': statusData.status,
        ':updatedAt': new Date().toISOString()
      },
      ReturnValues: 'ALL_NEW'
    }).promise();

    const updatedUser = result.Attributes;
    return {
      id: updatedUser.PK.replace('USER#', ''),
      email: updatedUser.email,
      name: updatedUser.name,
      role: updatedUser.role,
      status: updatedUser.status,
      organizationId: updatedUser.organizationId,
      phone: updatedUser.phone,
      createdAt: updatedUser.createdAt,
      updatedAt: updatedUser.updatedAt
    };

  } catch (error) {
    console.error('Error updating user status:', error);
    throw error;
  }
}

// Delete user
async function deleteUser(userId, authUser) {
  try {
    // Check if user exists and admin has access
    const existingUser = await getUser(userId, authUser);
    
    // Prevent users from deleting themselves
    if (userId === authUser.userId) {
      throw new Error('Cannot delete your own account');
    }

    // Delete user profile
    await dynamoDb.delete({
      TableName: TABLE_NAME,
      Key: {
        PK: `USER#${userId}`,
        SK: 'PROFILE#'
      }
    }).promise();

    // TODO: Also delete related user data (sessions, preferences, etc.)

    return {
      message: 'User deleted successfully',
      deletedUserId: userId
    };

  } catch (error) {
    console.error('Error deleting user:', error);
    throw error;
  }
}